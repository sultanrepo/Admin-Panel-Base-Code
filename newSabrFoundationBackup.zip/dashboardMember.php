<?php

//Session
include("session/sessionTrack.php");

// include header
include("header.php");

//include Top Nav Bar
include("navBarTop.php");

//Include Left Nav Bar
include("navBarLeft.php");

//Include dashboard Containt
include("dashboardMain.php");

//Include Footer
include("footer.php");

?>