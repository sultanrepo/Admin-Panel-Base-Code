<?php

session_start();

$getUserID = $_SESSION['user_id'];



?>