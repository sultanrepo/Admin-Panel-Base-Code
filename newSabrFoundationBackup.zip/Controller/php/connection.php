<?php
$servername = "localhost";
$username = "id21308246_sabrfoundation";//act
$password = "Sultan@81";//Adam@81
$dataBase = "id21308246_sabrfoundation";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dataBase);

// Check connection
// if (!$conn) {
//   die("Connection failed: " . mysqli_connect_error());
// }
// echo "Connected successfully";
?>