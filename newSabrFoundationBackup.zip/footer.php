
</div>
    <!-- /Wrapper -->

	<!-- jQuery -->
    <script src="vendors/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JS -->
   	<script src="vendors/bootstrap/dist/js/bootstrap.bundle.min.js"></script>

    <!-- FeatherIcons JS -->
    <script src="dist/js/feather.min.js"></script>

    <!-- Fancy Dropdown JS -->
    <script src="dist/js/dropdown-bootstrap-extended.js"></script>

	<!-- Simplebar JS -->
	<script src="vendors/simplebar/dist/simplebar.min.js"></script>
	
	<!-- Data Table JS -->
    <script src="vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="vendors/datatables.net-bs5/js/dataTables.bootstrap5.min.js"></script>
	<script src="vendors/datatables.net-select/js/dataTables.select.min.js"></script>

	<!-- Daterangepicker JS -->
    <script src="vendors/moment/min/moment.min.js"></script>
	<script src="vendors/daterangepicker/daterangepicker.js"></script>
	<script src="dist/js/daterangepicker-data.js"></script>

	<!-- Amcharts Maps JS -->
	<script src="vendors/%40amcharts/amcharts4/core.js"></script>
	<script src="vendors/%40amcharts/amcharts4/maps.js"></script>
	<script src="vendors/%40amcharts/amcharts4-geodata/worldLow.js"></script>
	<script src="vendors/%40amcharts/amcharts4-geodata/worldHigh.js"></script>
	<script src="vendors/%40amcharts/amcharts4/themes/animated.js"></script>

	<!-- Apex JS -->
	<script src="vendors/apexcharts/dist/apexcharts.min.js"></script>

	<!-- Init JS -->
	<script src="dist/js/init.js"></script>
	<script src="dist/js/chips-init.js"></script>
	<script src="dist/js/dashboard-data.js"></script>

	<!-- SweetAlert2 -->
	<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

	<!-- Profile Update Details Starts -->

	<!-- Upload Profile Photo -->
	<script src="Controller/js/uploadProfilePhoto.js"></script>

	<!-- Update Profile -->
	<script src="Controller/js/updateProfile.js"></script>

	<!-- Change Password -->
	<script src="Controller/js/changePassword.js"></script>

	<!-- Payment -->
	<script src="Controller/js/payment.js"></script>

	<!-- Profile Update Details Ends -->
</body>

<!-- Mirrored from hencework.com/theme/jampack/classic/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 10 Sep 2022 06:12:38 GMT -->
</html>